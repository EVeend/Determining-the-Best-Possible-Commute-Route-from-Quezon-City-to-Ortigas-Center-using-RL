library(hash)

modifiedExperiencePlay <- function(D, Q, control, ...) {
  if (!is.hash(Q)) {
    stop("Parameter Q must be of type hash.")
  }
  if(!is.data.frame(D)) {
    stop("Argument 'data' must be empty or of type 'data.frame'.")
  }
  if(sum(c("s", "a", "p", "s_new") %in% colnames(D)) != 4) {
    stop("Undefined columns specified.")
  }
  if (!is.list(control)) {
    stop("Argument 'control' must be of type 'list'.")
  }
  
  for (i in 1:nrow(D)) {
    d <- D[i, ]
    state <- d$s
    action <- d$a
    punishment <- d$p
    nextState <- d$s_new
    
    currentQ <- Q[[state]][[action]]
    if(has.key(nextState,Q)) {
      minNextQ <- min(values(Q[[nextState]]))
    } else{
      minNextQ <- 0
    }
    Q[[state]][[action]] <- currentQ + control$alpha *
      (punishment + control$gamma * minNextQ - currentQ)
  }
  
  out <- list(Q = Q)
  return(out)
}