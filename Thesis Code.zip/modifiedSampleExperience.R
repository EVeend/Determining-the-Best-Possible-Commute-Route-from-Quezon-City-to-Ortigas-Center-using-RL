modifiedSampleExperience <- function (N, env, dataset, states, goal_states, actions, actionSelection = "random", 
          control = list(alpha = 0.1, gamma = 0.1, epsilon = 0.1), 
          model = NULL, ...) 
{

  if (!(N > 0 && length(N) == 1 && is.numeric(N) && floor(N) == 
        N)) {
    stop("Argument 'N' should be an integer > 0.")
  }
  if (!is.function(env)) {
    stop("Argument 'env' describing the environment must be of type function.")
  }
  if (!is.character(states)) {
    stop("Arguments 'states' must be of type 'character'.")
  }
  if (!is.character(actions)) {
    stop("Arguments 'actions' must be of type 'character'.")
  }
  if (class(model) != "rl" && !is.null(model)) {
    stop("Argument 'model' must be empty or of type 'rl'.")
  }
  if (!is.list(control)) {
    stop("Argument 'control' must be of type 'list'.")
  }
  if (is.null(control$epsilon)) {
    stop("Missing or invalid control parameters.")
  }
  if (is.null(model)) {
    Q <- hash()
  }
  else {
    Q <- model$Q_hash
  }
  for (i in unique(states)[!unique(states) %in% names(Q)]) {
    Q[[i]] <- hash(unique(actions), rep(0, length(unique(actions))))
  }
  actionSelectionFunction <- modifiedLookupActionSelection(actionSelection)
  sampleStates <- sample(states, N, replace = T)
  sampleActions <- sapply(sampleStates, function(x) actionSelectionFunction(Q, 
                                                                            x, control$epsilon))
  # print("Sample Actions")
  # print(sampleActions)
  response <- lapply(1:length(sampleStates), function(x) env(dataset, goal_states, sampleStates[x],
                                                             sampleActions[x]))
  # response <- lapply(1:length(sampleStates), function(x) env(sampleStates[x], 
  #                                                            sampleActions[x]))
  response <- data.table::rbindlist(lapply(response, data.frame))
  out <- data.frame(State = sampleStates, Action = sampleActions, 
                    Punishment = response$Punishment, NextState = as.character(response$NextState), 
                    stringsAsFactors = F)
  return(out)
}