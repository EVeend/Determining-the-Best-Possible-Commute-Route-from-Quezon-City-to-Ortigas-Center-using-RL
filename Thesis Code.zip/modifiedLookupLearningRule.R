modifiedLookupLearningRule <- function(type) {
  if (type == "experienceReplay") {
    return(experienceReplay)
  }
  else if(type == "modifiedExperiencePlay"){
    return(modifiedExperiencePlay)
  }
  
  stop("Name of learning rule not recognized. Corresponding argument has an invalid value.")
}