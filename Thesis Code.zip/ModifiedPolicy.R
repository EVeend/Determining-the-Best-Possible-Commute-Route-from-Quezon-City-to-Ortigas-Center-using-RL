modifiedPolicy <- function(x) {
  UseMethod("modifiedPolicy", x)
}

#' @export
modifiedPolicy.matrix <- function(x) {
  policy <- colnames(x)[apply(x, 1, which.min)]
  names(policy) <- rownames(x)
  return(policy)
}

#' @export
modifiedPolicy.data.frame <- function(x) {
  return(policy(as.matrix(x)))
}

#' @export
modifiedPolicy.rl <- function(x) {
  return(policy(x$Q))
}

#' @export
modifiedPolicy.default <- function(x) {
  stop("Argument invalid.")
}