epsilonGreedyActionSelection <- function(Q, state, epsilon) {
  if (runif(1) <= epsilon) {
    best_action <- names(sample(values(Q[[state]]), 1))
  } else {
    best_action <- names(which.max(values(Q[[state]])))
  }
  return(best_action)
}

randomActionSelection <- function(Q, state, epsilon) {
  return(names(sample(values(Q[[state]]), 1)))
}


modifiedLookupActionSelection <- function(type) {
  if (type == "epsilon-greedy") {
    return(epsilonGreedyActionSelection)
  }
  if (type == "random") {
    return(randomActionSelection)
  }
  stop("Rule for action selection not recognized. Corresponding argument has an invalid value.")
}