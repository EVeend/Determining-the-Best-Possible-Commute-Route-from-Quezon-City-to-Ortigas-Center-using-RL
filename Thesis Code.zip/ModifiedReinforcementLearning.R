ModifiedReinforcementLearning <- function(data, s = "s", a = "a", p = "p", s_new = "s_new",
                                  learningRule = "modifiedExperiencePlay", iter = 1,
                                  control = list(alpha = 0.1, gamma = 0.1, epsilon = 0.1), verbose = F,
                                  model = NULL, ...) {
  if (!(iter > 0 && length(iter) == 1 && is.numeric(iter) && floor(iter) == iter)) {
    stop("Argument 'iter' should be an integer > 0.")
  }
  if(class(model) != "rl" && !is.null(model)) {
    stop("Argument 'model' must be empty or of type 'rl'.")
  }
  if (!is.list(control)) {
    stop("Argument 'control' must be of type 'list'.")
  }
  if (is.null(control$alpha) || is.null(control$gamma) || !is.numeric(control$alpha) || !is.numeric(control$gamma)) {
    stop("Missing or invalid control parameters.")
  }
  if (control > 1 || control < 0) {
    stop("Control parameter values must be between 0 and 1.")
  }
  if(!is.data.frame(data)) {
    stop("Argument 'data' must of type 'data.frame'.")
  }
  if("tbl" %in% class(data)) {
    data <- as.data.frame(data)
  }
  if(!(is.character(s) && is.character(a) && is.character(p) && is.character(s_new))) {
    stop("Arguments 's', 'a', 'r', and 's_new' must be of type 'character'.")
  }
  if(sum(c(s, a, p, s_new) %in% colnames(data)) != 4) {
    stop("Data columns invalid or not provided.")
  } else {
    d <- data.frame(
      s = data[, s],
      a = data[, a],
      p = data[, p],
      s_new = data[, s_new],
      stringsAsFactors = F
    )
    colnames(d)
  }
  if(!(is.character(d$s) && is.character(d$a) && is.character(d$s_new) && is.numeric(d$p))) {
    stop("Input data invalid. States and actions must be of type 'character', while rewards must be of type 'numeric'.")
  }
  if (is.null(model)) {
    Q <- hash()
    punishmentSequence <- c()
  } else {
    Q <- model$Q_hash
    punishmentSequence <- model$PunishmentSequence
  }
  for (i in unique(d$s)[!unique(d$s) %in% names(Q)]) {
    Q[[i]] <- hash(unique(d$a), rep(0, length(unique(d$a))))
  }
  
  agentFunction <- modifiedLookupLearningRule(learningRule)
  knowledge <- list("Q" = Q)
  learned <- list()
  for (i in 1:iter) {
    if (verbose) {
      cat0("Iteration: ", i, "\\" , iter)
    }
    learned[[i]] <- agentFunction(d, knowledge$Q, control)
    knowledge <- learned[[i]]
  }
  
  out <- list()
  out$Q_hash <- learned[[length(learned)]]$Q
  out$Q <- lapply(as.list(learned[[length(learned)]]$Q, all.names = T), function(x)
    as.list(x, all.names = T))
  out$Q <- t(data.frame(lapply(out$Q, unlist)))
  out$States <- rownames(out$Q)
  out$Actions <- colnames(out$Q)
  out$Policy <- modifiedPolicy(out$Q)
  out$LearningRule <- learningRule
  out$Punishment <- sum(d$p)
  out$PunishmentSequence <- c(punishmentSequence, rep(sum(d$p), iter))
  class(out) <- "rl"
  return(out)
}

#' @export
print.rl <- function(x, ...) {
  cat("State-Action function Q\n")
  print(x$Q)
  cat("\nPolicy\n")
  print(x$Policy)
  # cat("\nPunishment (last iteration)\n")
  # print(x$Punishment)
}

get_policy <- function(x,...){
  # cat("\nPolicy\n")
  # print(x$Policy)
  return(x)
}

#' @importFrom stats median sd
#' @export
summary.rl <- function(object, ...) {
  cat0("\nModel details")
  cat0("Learning rule:           ", object$LearningRule)
  cat0("Learning iterations:     ", length(object$PunishmentSequence))
  cat0("Number of states:        ", length(rownames(object$Q)))
  cat0("Number of actions:       ", length(colnames(object$Q)))
  cat0("Total Punishment:            ", object$Punishment)
  
  cat0("\nPunishment details (per iteration)")
  cat0("Min:                     ", min(object$PunishmentSequence))
  cat0("Max:                     ", max(object$PunishmentSequence))
  cat0("Average:                 ", mean(object$PunishmentSequence))
  cat0("Median:                  ", median(object$PunishmentSequence))
  cat0("Standard deviation:      ", sd(object$PunishmentSequence))
}

#' @export
predict.rl <- function(object, newdata = NULL, ...) {
  if (missing(newdata) || is.null(newdata)) {
    return(policy(object))
  }
  if (!is.vector(newdata)) {
    stop("Argument 'newdata' must be of type vector.")
  }
  
  p <- policy(object)
  if (!all(newdata %in% object$States)) {
    stop("Invalid state in argument 'newdata'.")
  }
  
  out <- p[sapply(newdata, function(y) which(names(p) == y))]
  names(out) <- NULL
  
  return(out)
}

#' @importFrom graphics plot
#' @export
plot.rl <- function(x, type = "o", xlab = "Learning iteration",
                    ylab = "Punishment", main = "Reinforcement learning curve", ...) {
  plot(x = seq(1:length(x$PunishmentSequence)), y = x$PunishmentSequence,
       type = type, xlab = xlab, ylab = ylab, main = main, ...)
}

cat0 <- function(...) {
  cat(..., "\n", sep = "")
}